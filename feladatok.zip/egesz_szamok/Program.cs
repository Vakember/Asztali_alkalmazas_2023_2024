﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace egesz_szamok
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> szamok = new List<int>();

            Console.WriteLine("Adjon meg egész számokat a listához, majd egy negatív számot a befejezéshez.");
            int bevitel;
            int legnagyobbParos = int.MinValue; 

            while (true)
            {
                Console.Write("Kérem adjon meg egy számot: ");
                if (int.TryParse(Console.ReadLine(), out bevitel))
                {
                    if (bevitel < 0)
                    {
                        break;
                    }
                    else
                    {
                        szamok.Add(bevitel);

                        if (bevitel % 2 == 0 && bevitel > legnagyobbParos)
                        {
                            legnagyobbParos = bevitel;
                        }
                    }
                }
                else
                {
                    Console.WriteLine("Nem megfelelő adat! Csak egész számot adjon meg.");
                }
            }

            if (szamok.Count == 0)
            {
                Console.WriteLine("Nem adott meg számokat a listához.");
            }
            else if (legnagyobbParos != int.MinValue)
            {
                Console.WriteLine($"A lista legnagyobb páros száma: {legnagyobbParos}");
            }
            else
            {
                Console.WriteLine("A listában nincs páros szám.");
            }
        }
    }
}
