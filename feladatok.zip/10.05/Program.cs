﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _10._05
{
    internal class Program
    {
        static void Main(string[] args)         
        {
            Console.WriteLine("Egy 10 fős osztály átlaga");



            int[] jegyek = new int[10];
            int osszeg = 0;
            for (int i = 0; i < 10; i++)
            {
                Console.Write($"Kérem a {i + 1}. jegyeket: ");
                jegyek[i] = int.Parse(Console.ReadLine());
                osszeg += jegyek[i];
            }
            double atlag = (double)osszeg / 10;
            int darab = 0;
            for (int i = 0; i < 10; i++)
            {
                if (jegyek[i] > atlag)
                    darab++;

            }
            Console.WriteLine($"Átlagon felettiek:  {darab}");
            Console.WriteLine($"Az átlaguk: {atlag}");
            Console.ReadKey();
        }
    }
}
    

