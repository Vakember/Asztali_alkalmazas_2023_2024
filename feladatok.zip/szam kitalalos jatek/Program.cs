﻿using Microsoft.Win32.SafeHandles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace szam_kitalalos_jatek
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Random random = new Random();
            int kitalalandoSzam = random.Next(101);
            int probalkozasok = 0;
            int tipp = -1;

            Console.WriteLine("Gondoltam egy számra 0 és 100 között. Próbáld meg kitalálni!");

            while (tipp != kitalalandoSzam)
            {
                Console.Write("Tippeld meg a számot: ");
                if (!int.TryParse(Console.ReadLine(), out tipp))
                {
                    Console.WriteLine("Kérlek adj meg egy érvényes számot.");
                    continue;
                }

                probalkozasok++;

                if (tipp < kitalalandoSzam)
                {
                    Console.WriteLine("A gondolt szám nagyobb.");
                }
                else if (tipp > kitalalandoSzam)
                {
                    Console.WriteLine("A gondolt szám kisebb.");
                }
                else
                {
                    Console.WriteLine($"Gratulálok! Kitaláltad a számot ({kitalalandoSzam}). Próbálkozások száma: {probalkozasok}");

                }
        }
    }
}
