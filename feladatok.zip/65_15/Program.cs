﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _65_15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random random = new Random();
            int[] szamok = new int[28];
            int pozitivSzamok = 0;
            int negativSzamok = 0;


            for (int i = 0; i < 28; i++)
            {
                szamok[i] = random.Next(-10, 11);
            }

            foreach (int szam in szamok)
            {
                if (szam > 0)
                {
                    pozitivSzamok++;
                }
                else if (szam < 0)
                {
                    negativSzamok++;
                }
            }

            Console.WriteLine("Generált számok:");
            foreach (int szam in szamok)
            {
                Console.Write(szam + " ");
            }
            Console.WriteLine("Pozitív számok száma: " + pozitivSzamok);
            Console.WriteLine("Negatív számok száma: " + negativSzamok);

            if (pozitivSzamok > negativSzamok)
            {
                Console.WriteLine("Több pozitív szám van.");
            }
            else if (negativSzamok > pozitivSzamok)
            {
                Console.WriteLine("Több negatív szám van.");
            }
            else
            {
                Console.WriteLine("Ugyanannyi pozitív és negatív szám van.");
               
            }
            Console.ReadKey();
        }
    }
}