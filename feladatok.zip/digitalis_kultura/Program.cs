﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace digitalis_kultura
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] szavak = {
            "fuvola", "csirke", "adatok", "asztal", "fogoly",
            "bicska", "farkas", "almafa", "babona", "gerinc",
            "dervis", "bagoly", "ecetes", "angyal", "boglya"
        };
            Random random = new Random();
            string rejtettSzo = szavak[random.Next(szavak.Length)];
            List<string> tippek = new List<string>();
            int tippekSzama = 0;
            while (true)
            {
                Console.Write("Tippelj egy hatbetűs szót (vagy írd be 'stop' a kilépéshez): ");
                string tipp = Console.ReadLine().ToLower();

                // 3. Ellenőrizze, hogy a felhasználó beírta-e a "stop" szót a kilépéshez
                if (tipp == "stop")
                {
                    Console.WriteLine("A játék leállítva. A rejtett szó: " + rejtettSzo);
                    break;
                }

                tippekSzama++;


                if (tipp.Length != 6)
                {
                    Console.WriteLine("A tippnek 6 karakterből kell állnia!");
                    continue;
                }

                tippek.Add(tipp);

                // Ellenőrizze a tipp helyességét
                int helyesBetuk = 0;
                for (int i = 0; i < rejtettSzo.Length; i++)
                {
                    if (rejtettSzo[i] == tipp[i])
                    {
                        helyesBetuk++;
                    }
                }

                if (helyesBetuk == 6)
                {
                    Console.WriteLine("Gratulálok, kitaláltad a szót: " + rejtettSzo);
                    break;
                }
                else
                {
                    Console.WriteLine("Nem találtad el az összes betűt. Eddig " + helyesBetuk + " helyes betűd van.");
                }
            }

            // 4. A játék végén írassa ki a megfejtéshez használt tippek számát
            Console.WriteLine("Kitaláláshoz használt tippek száma: " + tippekSzama);
        }
    }
}



