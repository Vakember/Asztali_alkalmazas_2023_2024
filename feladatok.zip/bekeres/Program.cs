﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace bekeres
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program végrehajta azokat a műveleteket amiket ön kiválaszt");

            double szam1, szam2;
            Console.WriteLine("Kérlek, add meg az első számot:");
            szam1 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Kérlek, add meg a második számot:");
            szam2 = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Válaszd ki a műveletet:");
            Console.WriteLine("1. Összeadás");
            Console.WriteLine("2. Kivonás");
            Console.WriteLine("3. Szorzás");
            Console.WriteLine("4. Osztás");

            int valasztas = Convert.ToInt32(Console.ReadLine());

            double eredmeny = 0;

            switch (valasztas)
            {
                case 1:
                    eredmeny = szam1 + szam2;
                    Console.WriteLine("Az eredmény: " + eredmeny);
                    break;


                case 2:
                    eredmeny = szam1 - szam2;
                    Console.WriteLine("Az eredmény: " + eredmeny);
                    break;
                case 3:
                    eredmeny = szam1 * szam2;
                    Console.WriteLine("Az eredmény: " + eredmeny);
                    break;
                case 4:
                    if (szam2 != 0)
                    {
                        eredmeny = szam1 / szam2;
                        Console.WriteLine("Az eredmény: " + eredmeny);
                    }
                    else
                    {
                        Console.WriteLine("Hibás művelet! Nullával nem osztható.");
                    }
                    break;
                default:
                    Console.WriteLine("Érvénytelen választás! Kérlek, válassz 1 és 4 közötti számot.");
                    break;
            }

            Console.ReadLine();
        }
        
    }
}
