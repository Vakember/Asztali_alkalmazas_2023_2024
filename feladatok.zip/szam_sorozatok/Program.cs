﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace szam_sorozatok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ez a program megoldja a számtani sorozatokat");
            int elso = 4;
            int differencia = 5;
            int n = 0;
            int darab = 2;
            int szam = 1004;

            while (n<=1000)
            {
                n = elso + (darab - 1) * differencia;
                Console.Write("{0}"+",",n);
                darab++;
            }
            szam = elso + (n - 1) * differencia;
            Console.WriteLine(szam);
            Console.ReadKey();



        }
    }
}
